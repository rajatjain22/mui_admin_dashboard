// import NewSideNav from "./components/Sidenav/NewSideNav";
import Sidenav from "./components/Sidenav/Sidenav";

function App() {
  return <Sidenav />;
  // return <NewSideNav />;
}

export default App;
